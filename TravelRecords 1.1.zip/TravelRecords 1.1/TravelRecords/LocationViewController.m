//  Siyuan Ye & Luqiao Yang, CIS 651, FINAL PROJECT
//  LocationViewController.m
//  TravelRecords
//  Help users to add travel records and store them with showing of map of photos.
//  Created by siyuan on 11/30/15.
//  Copyright © 2015 siyuan. All rights reserved.
//

@import CoreLocation;
#import "LocationViewController.h"
#import "ThirdViewController.h"

@interface LocationViewController ()
@property (nonatomic) NSString* locationName;
@property CLLocationManager *mgr;
@property CLLocation *latestLocation;
@end

@implementation LocationViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    // launch location service
    if ([CLLocationManager locationServicesEnabled]) {
        _mgr = [[CLLocationManager alloc] init];
        _mgr.desiredAccuracy = kCLLocationAccuracyBest;
        _mgr.distanceFilter = 50.0;
        _mgr.delegate = (id<CLLocationManagerDelegate>)self;
        if ([[[UIDevice currentDevice] systemVersion] doubleValue] >= 8.0) {
            [_mgr requestAlwaysAuthorization];
        }
    }
    [self.mgr startUpdatingLocation];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

// CLLocationManagerDelegate method that receives location updates
- (void)locationManager: (CLLocationManager *)manager
     didUpdateLocations: (NSArray<CLLocation *> *)locations
{
    static int updates = 0;
    NSLog(@"locationManager:didUpdateLocations:");
    NSLog(@"%d: %@\n\n", ++updates, [locations lastObject]);
    //[self.mymap setCenterCoordinate:[locations lastObject].coordinate animated:true];
    self.latestLocation = [locations lastObject];
    // reload the view
    //[self viewDidLoad];
    
}

//  Get current location button
- (IBAction)currentLocation:(id)sender {
    __block NSString *returnAddress = @"";
    CLGeocoder *geoCoder = [[CLGeocoder alloc] init];
    [geoCoder reverseGeocodeLocation:self.latestLocation completionHandler:^(NSArray *placemarks, NSError *error) {
        // if some errors happened
        if(error){
            NSLog(@"%@", [error localizedDescription]);
        }
        // get the newest location
        CLPlacemark *placemark = [placemarks lastObject];
        // make them more sensible to user
        NSString *addressString = [NSString stringWithFormat:@"%@, %@, %@", placemark.locality,
                              placemark.administrativeArea,
                              placemark.country];
        returnAddress = addressString;
        // print to console for debug
        NSLog(@"returnAddress");
        // call a method to execute the rest of the logic
        [self remainderOfMethodHereUsingReturnAddress:returnAddress];
    }];
}

- (void)remainderOfMethodHereUsingReturnAddress:(NSString*)returnAddress {
    // do things with returnAddress.
    self.textLocation.text = returnAddress;
}

#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Make sure your click the button or type sth.
    if (sender == self.doneButton) {
        self.locationName = self.textLocation.text;
    }
    if (self.locationName.length != 0) {
        // Get reference to the destination view controller
        ThirdViewController *vc = [segue destinationViewController];
        // Pass data
        [vc setLabelTitle:self.locationName];
    }
}



@end
