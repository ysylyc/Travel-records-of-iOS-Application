//  Siyuan Ye & Luqiao Yang, CIS 651, FINAL PROJECT
//  MapAnnotation.m
//  TravelRecords
//  Help users to add travel records and store them with showing of map of photos.
//  Created by siyuan on 11/30/15.
//  Copyright © 2015 siyuan. All rights reserved.
//

#import "MapAnnotation.h"

@implementation MapAnnotation

@end
