//  Siyuan Ye & Luqiao Yang, CIS 651, FINAL PROJECT
//  ThirdViewController.h
//  TravelRecords
//  Help users to add travel records and store them with showing of map of photos.
//  Created by siyuan on 11/30/15.
//  Copyright © 2015 siyuan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ThirdViewController : UIViewController<UIImagePickerControllerDelegate, UINavigationControllerDelegate, UITextFieldDelegate, UITextViewDelegate>

@property (nonatomic) IBOutlet UITextView *comments;
- (IBAction)addPhoto:(id)sender;
- (IBAction)deletePhoto:(id)sender;
@property (nonatomic) NSURL *photoURL;
@property (weak, nonatomic) IBOutlet UIImageView *photoPreview;
@property (weak, nonatomic) NSString *labelTitle;
@end
