//  Siyuan Ye & Luqiao Yang, CIS 651, FINAL PROJECT
//  SearchRTableViewController.h
//  TravelRecords
//  Help users to add travel records and store them with showing of map of photos.
//  Created by siyuan on 11/30/15.
//  Copyright © 2015 siyuan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SearchRTableViewController : UITableViewController
// get searched text from the previous view
@property (nonatomic) NSString* searchText;

@end

