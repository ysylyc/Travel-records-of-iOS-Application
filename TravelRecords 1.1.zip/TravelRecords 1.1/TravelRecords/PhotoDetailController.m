//  Siyuan Ye & Luqiao Yang, CIS 651, FINAL PROJECT
//  PhotoDetailController.m
//  TravelRecords
//  Help users to add travel records and store them with showing of map of photos.
//  Created by siyuan on 11/30/15.
//  Copyright © 2015 siyuan. All rights reserved.
//

#import "PhotoDetailController.h"
#import "PhotosCollectionViewController.h"
#import "DBManager.h"
@import Photos;

@interface PhotoDetailController ()
@property DBManager *dbManager;
@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (weak, nonatomic) IBOutlet UILabel *comments;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *like;
@property BOOL love;
- (IBAction)clickButton:(id)sender;

@end

@implementation PhotoDetailController
// set the image
- (void)showImageFromURL:(NSURL *)url {
    NSArray *tmp = [[NSArray alloc]initWithObjects:url, nil];
    //NSLog(@"%@",[tmp objectAtIndex:0]);
    PHFetchResult<PHAsset *> *result =  [PHAsset fetchAssetsWithALAssetURLs:tmp options:nil];
    if ([result count] == 0) {
        self.imageView.image = nil;
        return;
    }
    [[PHImageManager defaultManager] requestImageForAsset:[result objectAtIndex:0]
                                               targetSize:CGSizeMake(300, 300)
                                              contentMode:PHImageContentModeAspectFill
                                                  options:[[PHImageRequestOptions alloc]init]
                                            resultHandler:^(UIImage *img, NSDictionary *info){
                                                self.imageView.image = img;
                                            }];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationController.navigationBarHidden = NO;
    self.tabBarController.tabBar.hidden = YES;
    // Initialize the dbManager object.
    self.dbManager = [[DBManager alloc] initWithDatabaseFilename:@"mydb.sql"];
    // Load image
    NSURL *url = [[NSURL alloc] initWithString:[self.imageDetail objectAtIndex:4]];
    [self showImageFromURL:url];
    // set the date as title
    self.navigationController.topViewController.title = [self.imageDetail objectAtIndex:2];
    // set the comments
    self.comments.text = [[self.imageDetail objectAtIndex:3] stringByAppendingFormat:@"@%@",[self.imageDetail objectAtIndex:1]];
    self.comments.numberOfLines = 5;
    // set the favorites
    self.love = [[self.imageDetail objectAtIndex:5] integerValue];
    NSLog(@"%d", self.love);
    if (self.love == true) {
        self.like.image = [UIImage imageNamed:@"like-40"];
    }
    else self.like.image = [UIImage imageNamed:@"unlike-40"];
}

- (void)viewWillAppear:(BOOL)animated{
    self.navigationController.navigationBarHidden = NO;
    self.tabBarController.tabBar.hidden = YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

// favorites button
- (IBAction)clickButton:(id)sender {
    if (self.love == true) {
        self.love = false;
        self.like.image = [UIImage imageNamed:@"unlike-40"];
    }
    else {
        self.love = true;
        self.like.image = [UIImage imageNamed:@"like-40"];
    }
}

//  before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    if ([segue.identifier isEqualToString:@"unwind"]) {
        // update the database
        NSString *query = [NSString stringWithFormat:@"update photos set LIKE=%d where photoID=%@;", self.love, [self.imageDetail objectAtIndex:0]];
        NSLog(@"%@", query);
        // Execute the query.
        [self.dbManager executeQuery:query];
        // output the result
        if (self.dbManager.affectedRows != 0) {
            NSLog(@"Query was executed successfully. Affected rows = %d", self.dbManager.affectedRows);
        }
        else{
            NSLog(@"Could not execute the query.");
        }
        // update local record
        NSMutableArray *newResult = [[NSMutableArray alloc] initWithArray:@[[self.imageDetail objectAtIndex:0],[self.imageDetail objectAtIndex:1],[self.imageDetail objectAtIndex:2],[self.imageDetail objectAtIndex:3],[self.imageDetail objectAtIndex:4],[NSString stringWithFormat:@"%d", self.love]]];
        // update the destination view
        PhotosCollectionViewController *vc = [segue destinationViewController];
        [vc setModify:(NSMutableArray*)newResult];
    }
}



@end
