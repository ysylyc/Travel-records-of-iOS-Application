//  Siyuan Ye & Luqiao Yang, CIS 651, FINAL PROJECT
//  MapDetailViewController.h
//  TravelRecords
//  Help users to add travel records and store them with showing of map of photos.
//  Created by siyuan on 11/30/15.
//  Copyright © 2015 siyuan. All rights reserved.
//

#import <UIKit/UIKit.h>
@import MapKit;

@interface MapDetailViewController : UIViewController<MKMapViewDelegate>
@property (weak, nonatomic) IBOutlet MKMapView *mapView;
@property NSMutableArray *mapPins;
@end
