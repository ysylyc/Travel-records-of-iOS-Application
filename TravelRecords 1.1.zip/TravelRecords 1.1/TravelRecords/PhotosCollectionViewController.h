//  Siyuan Ye & Luqiao Yang, CIS 651, FINAL PROJECT
//  PhotosCollectionViewController.h
//  TravelRecords
//  Help users to add travel records and store them with showing of map of photos.
//  Created by siyuan on 11/30/15.
//  Copyright © 2015 siyuan. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface PhotosCollectionViewController : UICollectionViewController<UICollectionViewDataSource, UICollectionViewDelegate>
//  Array contains the whole URL of searched photos
//  Two-dimension array
@property (nonatomic) NSMutableArray *Photos;
@property (nonatomic) NSMutableArray *modify;

@end
