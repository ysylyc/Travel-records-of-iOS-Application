//  Siyuan Ye & Luqiao Yang, CIS 651, FINAL PROJECT
//  MapDetailViewController.m
//  TravelRecords
//  Help users to add travel records and store them with showing of map of photos.
//  Created by siyuan on 11/30/15.
//  Copyright © 2015 siyuan. All rights reserved.
//

#import "MapDetailViewController.h"
#import "PhotosCollectionViewController.h"
#import "MapAnnotation.h"
#import "DBManager.h"


@interface MapDetailViewController ()
@property (strong, nonatomic) DBManager *dbManager;
// store title of the clicked annotation
@property NSString *clickTitle;
// store subtitle of the clicked annotation
@property NSString *clickSubtitle;
@end

@implementation MapDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.navigationController.navigationBarHidden = NO;
    [self.mapView addAnnotations:self.mapPins];
    self.mapView.delegate = self;
}

- (void)viewWillAppear:(BOOL)animated {
    self.navigationController.navigationBarHidden = NO;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark MKMapViewDelegate

- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id <MKAnnotation>)annotation{
    // Don't mess user location
    if(![annotation isKindOfClass:[MapAnnotation class]])
        return nil;
    // Handle any custom annotations.
    // Try to dequeue an existing pin view first.
    MKPinAnnotationView *customPinView = (MKPinAnnotationView*)[mapView dequeueReusableAnnotationViewWithIdentifier:@"CustomPinAnnotationView"];
    if (!customPinView) {
        // If an existing pin view was not available, create one.
        customPinView = [[MKPinAnnotationView alloc] initWithAnnotation:annotation
                                                        reuseIdentifier:@"CustomPinAnnotationView"];
        customPinView.animatesDrop = YES;
        customPinView.canShowCallout = YES;
        // add the detail disclosure button to display details about the annotation in another view.
        //UIButton *rightButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
        customPinView.rightCalloutAccessoryView = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
        [(UIButton *)customPinView.rightCalloutAccessoryView addTarget:self action:@selector(openDetail:) forControlEvents:UIControlEventTouchUpInside];
        //customPinView.rightCalloutAccessoryView = rightButton;
        customPinView.enabled = YES;
        customPinView.canShowCallout = YES;
    }
    else customPinView.annotation = annotation;
    
    return customPinView;
}

- (IBAction)openDetail:(id)sender {
    NSLog(@"gorecord~~");
    [self performSegueWithIdentifier:@"gorecord" sender:self];
}

//when a user taps the annotation on the map.
- (void)mapView:(MKMapView *)mapView didSelectAnnotationView:(MKAnnotationView *)view{
    NSLog(@"%@", view.annotation.title);
    self.clickTitle = view.annotation.title;
    self.clickSubtitle = view.annotation.subtitle;
    //[mapView deselectAnnotation:view.annotation animated:YES];
}

- (void)mapView:(MKMapView *)mapView didDeselectAnnotationView:(MKAnnotationView *)view
{
}


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([[segue identifier] isEqualToString:@"gorecord"]){
        // Initialize the dbManager object.
        self.dbManager = [[DBManager alloc] initWithDatabaseFilename:@"mydb.sql"];
        NSString *query = [NSString stringWithFormat:@"select * from photos where PLACE = '%@' and DATE = '%@'", self.clickTitle, self.clickSubtitle];
        NSLog(@"%@", query);
        // Execute the query.
        NSMutableArray *result = [[NSMutableArray alloc] initWithArray:[self.dbManager loadDataFromDB:query]];
        NSLog(@"%lu", (unsigned long)[result count]);
        // Get reference to the destination view controller
        PhotosCollectionViewController *vc = [segue destinationViewController];
        // Pass data
        [vc setPhotos:result];
    }
}


@end
