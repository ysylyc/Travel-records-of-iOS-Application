//  Siyuan Ye & Luqiao Yang, CIS 651, FINAL PROJECT
//  SearchRTableViewController.m
//  TravelRecords
//  Help users to add travel records and store them with showing of map of photos.
//  Created by siyuan on 11/30/15.
//  Copyright © 2015 siyuan. All rights reserved.
//

#import "PhotosCollectionViewController.h"
#import "SearchRTableViewController.h"
#import "DBManager.h"

@interface SearchRTableViewController ()
// store all the records meet search text
@property (nonatomic)NSMutableArray* result;
// store one of the records that clicked
@property (nonatomic)NSMutableArray* passResult;
// handler of database
@property (strong, nonatomic) DBManager *dbManager;
@property (weak, nonatomic)NSString *sectionTitle;
@end

@implementation SearchRTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationController.navigationBarHidden = NO;
    // Initialize the dbManager object.
    self.dbManager = [[DBManager alloc] initWithDatabaseFilename:@"mydb.sql"];
    NSString *query = [NSString stringWithFormat:@"select * from photos where PLACE LIKE '%%%@%%'", self.searchText];
    NSLog(@"%@", query);
    // Execute the query.
    self.result = [[NSMutableArray alloc] initWithArray:[self.dbManager loadDataFromDB:query]];
    if ([self.result count] == 0) {
        self.sectionTitle = @"NOT FOUND";
    }
    else self.sectionTitle = self.searchText;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
    return [self.result count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *CellIdentifier = @"resultcell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
    //  get the index of date in the table of database
    NSInteger indexOfDate = [self.dbManager.arrColumnNames indexOfObject:@"DATE"];
    //  reveal the date
    cell.textLabel.text = [[self.result objectAtIndex:indexPath.row] objectAtIndex:indexOfDate];
    return cell;
}

#pragma mark - Table view delegate

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    return self.sectionTitle;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
    // get the time of selected item
    NSString *date = [self.tableView cellForRowAtIndexPath:indexPath].textLabel.text;
    // search the records match the place and time
    NSString *query = [NSString stringWithFormat:@"select * from photos where PLACE LIKE '%%%@%%' and DATE = '%@'", self.searchText, date];
    // Execute the query.
    self.passResult = [[NSMutableArray alloc] initWithArray:[self.dbManager loadDataFromDB:query]];
    //[[self navigationController] pushViewController:nextPage animated:YES];
    [self performSegueWithIdentifier:@"gophoto" sender:self.view];
}

#pragma mark - Navigation

//  In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Make sure your segue name in storyboard is the same as this line
    if ([[segue identifier] isEqualToString:@"gophoto"]){
        // Get reference to the destination view controller
        PhotosCollectionViewController *vc = [segue destinationViewController];
        // Pass data
        [vc setPhotos:(NSMutableArray *)self.passResult];
    }
    
}



@end
