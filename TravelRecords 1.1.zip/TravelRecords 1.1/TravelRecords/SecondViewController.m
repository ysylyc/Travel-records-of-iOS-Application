//  Siyuan Ye & Luqiao Yang, CIS 651, FINAL PROJECT
//  SecondViewController.m
//  TravelRecords
//  Help users to add travel records and store them with showing of map of photos.
//  Created by siyuan on 11/30/15.
//  Copyright © 2015 siyuan. All rights reserved.
//
@import AssetsLibrary;
@import Photos;
#import <MapKit/MapKit.h>
#import "SecondViewController.h"
#import "PhotosCollectionViewController.h"
#import "MapDetailViewController.h"
#import "MapAnnotation.h"
#import "DBManager.h"

@interface SecondViewController ()
@property (weak, nonatomic) IBOutlet UILabel *mapLabel;
@property (weak, nonatomic) IBOutlet UIImageView *photosOverview;
@property (nonatomic, strong) DBManager *dbManager;
// contains all annotations
@property NSMutableArray *mapPins;
// mark number, let us know when the transfer, address to coordinate, is finished
@property NSInteger mark;
@property (weak, nonatomic) IBOutlet MKMapView *mapView;
@end

// North America
#define NM_LATITUDE 54.5259614;
#define NM_LONGITUDE -105.25511870000003;

// Span
#define THE_SPAN 30.00f;

@implementation SecondViewController

- (IBAction)unwindToSecond:(UIStoryboardSegue *)segue {
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationController.navigationBarHidden = YES;
    self.success = TRUE;
    // Do any additional setup after loading the view, typically from a nib.
    // Initialize the dbManager property.
    self.dbManager = [[DBManager alloc] initWithDatabaseFilename:@"mydb.sql"];
}

- (void) viewWillAppear:(BOOL)animated{
    self.navigationController.navigationBarHidden = YES;
    self.tabBarController.tabBar.hidden = NO;
    self.mapLabel.layer.zPosition = 1;
    if (self.success == FALSE) {
        //  set the success to default value
        self.success = TRUE;
        // alert notification
        UIAlertController *alert = [UIAlertController
                                    alertControllerWithTitle:@"Upload failed."
                                    message:@"You don't meet the location or image requirements."
                                    preferredStyle:UIAlertControllerStyleAlert];
        // cancel alert
        UIAlertAction *cancel =  [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleCancel handler:nil];
        [alert addAction:cancel];
        [self presentViewController:alert animated:YES completion:nil];
    }
    // reload
    [self loadData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)showImageFromURL:(NSURL *)url {
    NSArray *tmp = [[NSArray alloc]initWithObjects:url, nil];
    NSLog(@"%@",[tmp objectAtIndex:0]);
    PHFetchResult<PHAsset *> *result =  [PHAsset fetchAssetsWithALAssetURLs:tmp options:nil];
    if ([result count] == 0) {
        return;
    }
    [[PHImageManager defaultManager] requestImageForAsset:[result objectAtIndex:0]
                                               targetSize:CGSizeMake(300, 300)
                                              contentMode:PHImageContentModeAspectFill
                                                  options:[[PHImageRequestOptions alloc]init]
                                            resultHandler:^(UIImage *img, NSDictionary *info){
                                                self.photosOverview.image = img;
                                            }];
}

- (void)loadImage {
    // get the URL, in the last of Table
    NSURL *url = [NSURL URLWithString:[[self.photos lastObject]objectAtIndex:4]];
    // show the image
    [self showImageFromURL:url];
}

- (void)loadData {
    // Form the query.
    NSString *query = @"select * from photos";
    // NSLog(@"%@", query);
    // Get the results.
    if (self.photos != nil) {
        self.photos = nil;
    }
    self.photos = [[NSMutableArray alloc] initWithArray:[self.dbManager loadDataFromDB:query]];
    NSLog(@"%lu", (unsigned long)[self.photos count]);
    if ([self.photos count] == 0) {
        self.photosOverview.image = [UIImage imageNamed:@"notfound"];
        return;
    }
    // Reload the image
    [self loadImage];
    // load the map
    [self loadMap];
}

- (void)loadMap {
    // set the main region
    MKCoordinateRegion mainRegion;
    MKCoordinateSpan span;
    CLLocationCoordinate2D center;
    span.latitudeDelta = THE_SPAN;
    span.longitudeDelta = THE_SPAN;
    center.latitude = NM_LATITUDE;
    center.longitude = NM_LONGITUDE;
    mainRegion.center = center;
    mainRegion.span = span;
    // set the mapview
    [self.mapView setRegion:mainRegion animated:FALSE];
    // the array store all the annotations
    self.mapPins = [[NSMutableArray alloc]init];
    // reset async mark
    self.mark = 0;
    // single record each time
    for (NSMutableArray *singleRecord in self.photos) {
        // pass the singel record for setting map
        [self geocodeFromRecord:singleRecord];
    }
}

- (void) geocodeFromRecord:(NSMutableArray *)singleRecord {
    // init Geocoder for forwarding
    CLGeocoder *geocoder = [[CLGeocoder alloc] init];
    [geocoder geocodeAddressString:[singleRecord objectAtIndex:1] completionHandler:^(NSArray *placemarks, NSError *error) {
        if([placemarks count]) {
            CLPlacemark *placemark = [placemarks objectAtIndex:0];
            CLLocation *location = placemark.location;
            CLLocationCoordinate2D coordinate = location.coordinate;
            // make a new annotation
            MapAnnotation *myAnnotation = [[MapAnnotation alloc]init];
            
            // set place name on title
            myAnnotation.title = [singleRecord objectAtIndex:1];
            
            // show time on subtitle
            myAnnotation.subtitle = [singleRecord objectAtIndex:2];
            
            // set the coordinate
            myAnnotation.coordinate = coordinate;
            
            // print for debug
            NSLog(@"coordinate = (%f, %f)", coordinate.latitude, coordinate.longitude);
            
            // set the map
            [self setMapWithAnnotation:myAnnotation];
        } else {
            NSLog(@"error");
            self.mark++;
            if (self.mark == [self.photos count]) {
                [self.mapView addAnnotations:self.mapPins];
            }

        }
    }];
}

// do this cause the block is async
- (void) setMapWithAnnotation:(MapAnnotation *) myAnnotation{
    [self.mapPins addObject:myAnnotation];
    self.mark++;
    // show the pins when all annotation got load
    if (self.mark == [self.photos count]) {
        [self.mapView addAnnotations:self.mapPins];
    }
}

#pragma mark - Navigation

//  In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Make sure your segue name in storyboard is the same as this line
    if ([[segue identifier] isEqualToString:@"Secondgophoto"])
    {
        // Get reference to the destination view controller
        PhotosCollectionViewController *vc = [segue destinationViewController];
        // Pass data
        [vc setPhotos:(NSMutableArray*)self.photos];
    }
    if ([[segue identifier] isEqualToString:@"gomap"]) {
        // Get reference to the destination view controller
        MapDetailViewController *vc = [segue destinationViewController];
        // Pass data
        [vc setMapView:self.mapView];
        [vc setMapPins:self.mapPins];
    }
}

@end
