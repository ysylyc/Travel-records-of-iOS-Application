//  Siyuan Ye & Luqiao Yang, CIS 651, FINAL PROJECT
//  ThirdViewController.m
//  TravelRecords
//  Help users to add travel records and store them with showing of map of photos.
//  Created by siyuan on 11/30/15.
//  Copyright © 2015 siyuan. All rights reserved.
//

#import "ThirdViewController.h"
#import "SecondViewController.h"
#import "ZoomViewController.h"
@import AssetsLibrary;
#import "DBManager.h"

@interface ThirdViewController ()
@property (weak, nonatomic) IBOutlet UILabel *locationEditer;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *doneButton;
@property (strong, nonatomic) DBManager *dbManager;
@end

@implementation ThirdViewController

- (IBAction)unwindToThird:(UIStoryboardSegue *)segue {
    if (self.labelTitle.length != 0) {
        self.locationEditer.text = self.labelTitle;
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.comments.delegate = self;
    // Create and initialize a tap gesture
    UITapGestureRecognizer *tapRecognizer = [[UITapGestureRecognizer alloc]
                                             initWithTarget:self action:@selector(handlerForTap:)];
    UITapGestureRecognizer *tapForLocation = [[UITapGestureRecognizer alloc]
                                             initWithTarget:self action:@selector(tapLocation:)];
    // Specify that the gesture must be a single tap
    tapRecognizer.numberOfTapsRequired = 1;
    tapForLocation.numberOfTapsRequired = 1;
    // Add the tap gesture recognizer to the pickview
    self.photoPreview.userInteractionEnabled = YES;
    [self.photoPreview addGestureRecognizer:tapRecognizer];
    self.locationEditer.userInteractionEnabled = YES;
    [self.locationEditer addGestureRecognizer:tapForLocation];
    // Initialize the dbManager object.
    self.dbManager = [[DBManager alloc] initWithDatabaseFilename:@"mydb.sql"];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

//  UIAlertAction button
- (IBAction)addPhoto:(id)sender {
    UIImagePickerController *picker = [[UIImagePickerController alloc]init];
    picker.delegate = self;
    // add photo action
    UIAlertController *options = [UIAlertController
                                  alertControllerWithTitle:nil
                                  message:nil
                                  preferredStyle:UIAlertControllerStyleActionSheet];
    UIAlertAction *takePhoto =  [UIAlertAction actionWithTitle:@"Take a new one" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action)
                                 {
                                     picker.sourceType = UIImagePickerControllerSourceTypeCamera;
                                     [self presentViewController:picker animated:true completion:nil];
                                 }];
    UIAlertAction *chooseOne =  [UIAlertAction actionWithTitle:@"Choose existence" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action)
                                 {
                                     picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
                                     [self presentViewController:picker animated:true completion:nil];
                                 }];
    UIAlertAction *cancel =  [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:^(UIAlertAction *action)
                                 {
                                     NSLog(@"cancelled.");
                                 }];
    [options addAction:takePhoto];
    [options addAction:chooseOne];
    [options addAction:cancel];
    [self presentViewController:options animated:YES completion:nil];
}

// textview delegate, tuck up keyboard
- (BOOL)textView:(UITextView *)textView
shouldChangeTextInRange:(NSRange)range
 replacementText:(NSString *)text
{
    if ([text isEqualToString:@"\n"])
    {
        [textView resignFirstResponder];
    }
    return YES;
}


// delete the photo
- (IBAction)deletePhoto:(id)sender {
    self.photoPreview.image = nil;
}


#pragma mark - Navigation

-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info{
    self.photoPreview.image = (UIImage*) info[UIImagePickerControllerOriginalImage];
    self.photoURL = [info valueForKey:UIImagePickerControllerReferenceURL];
    if (!self.photoURL) {
        // Save image
        ALAssetsLibrary *library = [[ALAssetsLibrary alloc] init];
        // Request to save the image to camera roll
        [library writeImageToSavedPhotosAlbum:[self.photoPreview.image CGImage] orientation:(ALAssetOrientation)[self.photoPreview.image imageOrientation] completionBlock:^(NSURL *assetURL, NSError *error){
            if (error) {
                NSLog(@"error");
            } else {
                NSLog(@"saved url %@", assetURL);
                self.photoURL = assetURL;
            }  
        }];
    }
    [self dismissViewControllerAnimated:true completion:nil];
}

- (void)image:(UIImage *)image didFinishSavingWithError:(NSError *)error contextInfo:(void *)contextInfo
{
    if (error) {
        NSLog(@"Error, Unable to save image to Photo Album.");
    }
    else NSLog(@"Success, Image saved to Photo Album.");
}

//  TapGesture handler
- (IBAction)handlerForTap:(UITapGestureRecognizer *)sender {
    if (self.photoPreview.image != nil) {
        [self performSegueWithIdentifier:@"showImage" sender:self];
    }
}

//  TapGesture handler for location
- (IBAction)tapLocation:(id)sender{
    [self performSegueWithIdentifier:@"editLocation" sender:self];
}

//  before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    if ([segue.identifier isEqualToString:@"showImage"]) {
        // pass the data to next view
        ZoomViewController *vc = [segue destinationViewController];
        [vc setSource:self.photoPreview.image];
    }
    if ([segue.identifier isEqualToString:@"editLocation"]) {
        // I might do sth. before going to location view in the future
    }
    if (sender == self.doneButton) {
        if (self.photoPreview.image == nil || [self.locationEditer.text isEqualToString:@"Location                                                      >"]) {
            // pass the data to next view
            SecondViewController *vc = [segue destinationViewController];
            [vc setSuccess:FALSE];
        }
        else {
            // get current date/time
            NSDate *today = [NSDate date];
            NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
            [dateFormatter setDateFormat:@"yyyy-MM-dd"];
            NSString *currentTime = [dateFormatter stringFromDate:today];
            //NSLog(@"%@",currentTime);
            // Prepare the query string.
            NSString *query = [NSString stringWithFormat:@"insert into photos values(null, '%@', '%@', '%@', '%@', %d)", self.locationEditer.text, currentTime, self.comments.text, self.photoURL, FALSE];
            NSLog(@"%@", query);
            // Execute the query.
            [self.dbManager executeQuery:query];
            
            // If the query was successfully executed then pop the view controller.
            if (self.dbManager.affectedRows != 0) {
                NSLog(@"Query was executed successfully. Affected rows = %d", self.dbManager.affectedRows);
            }
            else{
                NSLog(@"Could not execute the query.");
            }
        }
    }
}






@end
