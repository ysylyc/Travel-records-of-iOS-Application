//  Siyuan Ye & Luqiao Yang, CIS 651, FINAL PROJECT
//  PhotosCollectionViewController.m
//  TravelRecords
//  Help users to add travel records and store them with showing of map of photos.
//  Created by siyuan on 11/30/15.
//  Copyright © 2015 siyuan. All rights reserved.
//

#import "PhotosCollectionViewController.h"
#import "PhotoCell.h"
#import "PhotoDetailController.h"
@import Foundation;
@import Photos;

@interface PhotosCollectionViewController ()
@property (strong, nonatomic) IBOutlet UICollectionView *photosCollection;
@end

@implementation PhotosCollectionViewController
// when forward view gets back here
- (IBAction)unwindToPhotoCollection:(UIStoryboardSegue *)segue {
    int i = 0;
    // traverse the records in case the value of like has been changed
    for (NSMutableArray* tmp in self.Photos) {
        // compare records ID
        if ([[tmp objectAtIndex:0] integerValue] == [[self.modify objectAtIndex:0] integerValue]) {
            // replace the record
            [self.Photos replaceObjectAtIndex:i withObject:self.modify];
            return;
        }
        i++;
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationController.navigationBarHidden = NO;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark <UICollectionViewDataSource>

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 1;
}


- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return [self.Photos count];
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    PhotoCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"photoCell" forIndexPath:indexPath];
    // get the URL, in the last of Table
    NSURL *url = [NSURL URLWithString:[[self.Photos objectAtIndex:indexPath.row]objectAtIndex:4]];
    // store url into an array
    NSArray *tmp = [[NSArray alloc]initWithObjects:url, nil];
    //NSLog(@"%@",[tmp objectAtIndex:0]);
    // get asset from url
    PHFetchResult<PHAsset *> *result =  [PHAsset fetchAssetsWithALAssetURLs:tmp options:nil];
    if ([result count] == 0) {
        cell.photoView.image = nil;
        return cell;
    }
    [[PHImageManager defaultManager] requestImageForAsset:[result objectAtIndex:0]
                                               targetSize:CGSizeMake(300, 300)
                                              contentMode:PHImageContentModeAspectFill
                                                  options:[[PHImageRequestOptions alloc]init]
                                            resultHandler:^(UIImage *img, NSDictionary *info) {
                                                // set the image
                                                cell.photoView.image = img;
                                            }];
    return cell;
}

#pragma mark <UICollectionViewDelegate>

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    // call the segue
    [self performSegueWithIdentifier:@"showImage" sender:self];
}
//  before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    if ([segue.identifier isEqualToString:@"showImage"]) {
        // The indexPathsForSelectedItems returns an array of indexPaths (since there might be several items selected)
        NSMutableArray *indexPaths = [[NSMutableArray alloc]initWithArray:[self.photosCollection indexPathsForSelectedItems]];
        NSIndexPath *indexPath = [indexPaths objectAtIndex:0];
        // pass the data to next view
        PhotoDetailController *vc = [segue destinationViewController];
        [vc setImageDetail:(NSMutableArray*)[self.Photos objectAtIndex:indexPath.row]];
    }
}

@end

