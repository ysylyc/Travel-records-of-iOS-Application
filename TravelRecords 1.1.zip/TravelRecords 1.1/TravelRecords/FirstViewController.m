//  Siyuan Ye & Luqiao Yang, CIS 651, FINAL PROJECT
//  FirstViewController.m
//  TravelRecords
//  Help users to add travel records and store them with showing of map of photos.
//  Created by siyuan on 11/30/15.
//  Copyright © 2015 siyuan. All rights reserved.
//

#import "FirstViewController.h"
#import "SearchRTableViewController.h"
#import "DBManager.h"
#import "PhotosCollectionViewController.h"

@interface FirstViewController ()
// search bar
@property (nonatomic) NSString* searchText;
- (IBAction)goFavorites:(id)sender;
@property (strong, nonatomic) DBManager *dbManager;
@property (weak, nonatomic) IBOutlet UIImageView *ad1;
@property (weak, nonatomic) IBOutlet UIImageView *ad2;
@property (weak, nonatomic) IBOutlet UIImageView *ad3;
- (IBAction)act1:(id)sender;
- (IBAction)act2:(id)sender;
- (IBAction)act3:(id)sender;
@end

@implementation FirstViewController

// load advertisement
- (void)loadAD {
    // get url
    NSURL *url1 = [NSURL URLWithString:@"http://wallpapers.7savers.com/san-francisco-wallpapers_2781_1152.jpg"];
    NSURL *url2 = [NSURL URLWithString:@"http://travel.nationalgeographic.com/u/TvyamNb-BivtNwpvn7Sct0VFDulyAfA9wBcU0gVHVnqC5ghsgrXILQwdcn723WHNCUWn6mSfdHL0DLHFLA/"];
    NSURL *url3 = [NSURL URLWithString:@"http://www.pageresource.com/wallpapers/wallpaper/cool-las-vegas-hotels.jpg"];
    // get data
    NSData *data1 = [NSData dataWithContentsOfURL:url1];
    NSData *data2 = [NSData dataWithContentsOfURL:url2];
    NSData *data3 = [NSData dataWithContentsOfURL:url3];
    self.ad1.image = [[UIImage alloc] initWithData:data1];
    self.ad2.image = [[UIImage alloc] initWithData:data2];
    self.ad3.image = [[UIImage alloc] initWithData:data3];
    // Create and initialize a tap gesture
    UITapGestureRecognizer *tapRecognizer1 = [[UITapGestureRecognizer alloc]
                                             initWithTarget:self action:@selector(act1:)];
    UITapGestureRecognizer *tapRecognizer2 = [[UITapGestureRecognizer alloc]
                                              initWithTarget:self action:@selector(act2:)];
    UITapGestureRecognizer *tapRecognizer3 = [[UITapGestureRecognizer alloc]
                                              initWithTarget:self action:@selector(act3:)];
    // Specify that the gesture must be a single tap
    tapRecognizer1.numberOfTapsRequired = 1;
    tapRecognizer2.numberOfTapsRequired = 1;
    tapRecognizer3.numberOfTapsRequired = 1;
    // Add the tap gesture recognizer to the pickview
    self.ad1.userInteractionEnabled = YES;
    [self.ad1 addGestureRecognizer:tapRecognizer1];
    self.ad2.userInteractionEnabled = YES;
    [self.ad2 addGestureRecognizer:tapRecognizer2];
    self.ad3.userInteractionEnabled = YES;
    [self.ad3 addGestureRecognizer:tapRecognizer3];
}


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.textField.delegate = self;
    self.navigationController.navigationBarHidden = YES;
    [self loadAD];
}

// every time this view gets appeared
- (void)viewWillAppear:(BOOL)animated{
    self.navigationController.navigationBarHidden = YES;
    self.tabBarController.tabBar.hidden = NO;
    [self loadAD];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

// Textfiled delegate
- (BOOL) textFieldShouldReturn:(UITextField *)textField {
    // disappear the keyboard
    if (textField == self.textField) {
        [textField resignFirstResponder];
    }
    self.searchText = textField.text;
    [self performSegueWithIdentifier:@"gonext" sender:self];
    return YES;
}

#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Make sure your segue name in storyboard is the same as this line
    if ([[segue identifier] isEqualToString:@"gonext"])
    {
        // Get reference to the destination view controller
        SearchRTableViewController *tbvc = [segue destinationViewController];
        // Pass data
        [tbvc setSearchText:self.searchText];
    }
    if ([[segue identifier] isEqualToString:@"goFavorites"]) {
        // Initialize the dbManager object.
        self.dbManager = [[DBManager alloc] initWithDatabaseFilename:@"mydb.sql"];
        NSString *query = [NSString stringWithFormat:@"select * from photos where LIKE = 1"];
        NSLog(@"%@", query);
        // Execute the query.
        NSMutableArray *result = [[NSMutableArray alloc] initWithArray:[self.dbManager loadDataFromDB:query]];
        // Get reference to the destination view controller
        PhotosCollectionViewController *tbvc = [segue destinationViewController];
        // Pass data
        [tbvc setPhotos:result];
    }
}

// when click the favorites button
- (IBAction)goFavorites:(id)sender {
    [self performSegueWithIdentifier:@"goFavorites" sender:self];
}

// open safari
- (IBAction)act1:(id)sender {
    NSLog(@"ad1");
    NSURL *url = [NSURL URLWithString:@"http://www.tripadvisor.com/ShowUserReviews-g60713-d526082-r320801946-Scenic_49_Mile_Drive-San_Francisco_California.html"];
    [[UIApplication sharedApplication] openURL:url];
}

- (IBAction)act2:(id)sender {
    NSLog(@"ad2");
    NSURL *url = [NSURL URLWithString:@"http://www.gorp.com/parks-guide/travel-ta-family-day-hiking-hiking-backpacking-montana-gardiner-yellowstone-national-park-sidwcmdev_060500.html"];
    [[UIApplication sharedApplication] openURL:url];
}

- (IBAction)act3:(id)sender {
    NSLog(@"ad3");
    NSURL *url = [NSURL URLWithString:@"http://travelnevada.com/regions/southern/las-vegas"];
    [[UIApplication sharedApplication] openURL:url];
}
@end
