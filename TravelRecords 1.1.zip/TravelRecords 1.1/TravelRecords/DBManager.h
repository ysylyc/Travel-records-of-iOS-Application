//
//  DBManager.h
//  ToDoList
//
//  Created by siyuan on 12/5/15.
//  Copyright © 2015 siyuan ye. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DBManager : NSObject

-(instancetype)initWithDatabaseFilename:(NSString *)dbFilename;


@property (nonatomic, strong) NSMutableArray *arrColumnNames;
@property (nonatomic) int affectedRows;
@property (nonatomic) long long lastInsertedRowID;

-(NSMutableArray *)loadDataFromDB:(NSString *)query;
-(void)executeQuery:(NSString *)query;

@end
